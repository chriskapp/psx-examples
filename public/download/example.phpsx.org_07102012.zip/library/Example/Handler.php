<?php

class Example_Handler extends PSX_Data_HandlerAbstract
{
}
