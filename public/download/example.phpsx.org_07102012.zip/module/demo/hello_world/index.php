<?php

class index extends PSX_ModuleAbstract
{
	public function onLoad()
	{
		echo 'Hello World!';
	}
}
